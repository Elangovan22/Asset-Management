alter table AMS_INSTANCE drop column STATUS cascade ;
